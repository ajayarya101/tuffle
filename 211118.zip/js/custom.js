// JavaScript Document

$(document).ready(function() {
 'use strict';
 var main_function = function(e) {
  stopAnimation();
  $("#ambience_content").fadeOut();
  $("#product_content").fadeOut();
  $("#service_content").fadeOut();
  $('html, body').stop().animate();
  $("input[type='radio']").prop("checked", false);
  var val = e.value;
  if (val >= 1 && val <= 10) {
   $("#rating").val(val);
  } else {
   $("#rating").val(0);
  }
  $("#feedback-content").fadeIn();
  animationFunction();
  var animatio1;
  var animatio2;

  function animationFunction() {
   animatio1 = setTimeout(function() {
    $('html, body').animate({
     scrollTop: $("#scroll1").offset().top
    }, 1000);
    animatio2 = setTimeout(function() {
     $('html, body').animate({
      scrollTop: $("#more").offset().top
     }, 1000);
    }, 2000);
   }, 0);
  }

  function stopAnimation() {
   clearTimeout(animatio1);
   clearTimeout(animatio2);
  }
  //$(".feedback_number span").text(val);
  if (val <= 2) {
   //console.log(val);
   $("#questions").fadeIn();
   $("#fd_txt").text("Sorry! Let us know what went wrong? ");
  
  } else if (val <= 6) {
   $("#questions").fadeIn();
   $("#fd_txt").text("Sorry! Let us know what went wrong? ");
  } else if (val <= 8) {
   $("#questions").fadeIn();
   $("#fd_txt").text(" Oops! We missed a chance of being your favourite.");
  } else {
   $("#questions").fadeOut();
   $("#fd_txt").text("Great! We are delighted to serve you. See you soon!");
  }
 };	
	$("#slider").roundSlider({
				handleShape: "dot",
				width: 35,
				radius: 150,
			    min:0,
				value: 8,
				startAngle: 90,
				handleSize: "+25",
				max: "10",
			   	editableTooltip:false,
				sliderType: "min-range",
				drag: main_function,
				change: main_function
			});
	
	$('.questionSection .level1 input[type=radio]').on('change', function() {
  var rd_val = $(this).val();
  $(this).parents(".questionSection").find(".level2 input[type=radio]").prop('checked', false);
  $(this).prop('checked', true);
  if (rd_val == 1) {
   $(this).parents(".questionSection").find(".level2").fadeIn();
  } else {
   $(this).parents(".questionSection").find(".level2").fadeOut();
  }
 });
 $('.questionSection .level2 .answers:last-child input[type=radio]').on("change", function() {
  var nextQuestion = $(this).parents(".questionSection").next(".questionSection");
  setTimeout(function() {
   $('html, body').animate({
    scrollTop: nextQuestion.offset().top
   }, 1000);
  });
 });
	
});